from . import BasicTest, TestAll, TestTask1, TestTask2, TestTask3, TestTask4, TestTask5Cookie, TestTask5Session
