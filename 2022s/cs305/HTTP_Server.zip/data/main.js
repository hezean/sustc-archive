console.log("javascript is awesome");
alert("Thanks for inventing Javascript.");